/* Program   : mmatriks.c */
/* Deskripsi : driver ADT matriks integer */
/* NIM/Nama  : 24060124130069/Muhammad Fikri*/
/* Tanggal   : 18 September 2025*/
/***********************************/

#include <stdio.h>

int main()
{
	/*kamus*/

	/*algoritma*/

	return 0;
}
